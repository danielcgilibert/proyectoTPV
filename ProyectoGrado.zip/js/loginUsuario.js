$(document).ready(function () {
  $("#iniciarLogin").on("click", function (event) {
    let email = $("#emailLogin").val().trim();
    let password = $("#passwordLogin").val().trim();


  });
});
