<?php

    $host = 'localhost'; 
    $baseDatos = 'gradotpv'; 
    $usuario = 'root'; 
    $contrasenia = ''; 

?>